package com.wechatjz.demo.controller;

import com.wechatjz.api.model.common.WxVerificationModel;
import com.wechatjz.api.model.vo.JsSignVO;
import com.wechatjz.api.model.vo.UserWxVO;
import com.wechatjz.api.service.UserService;
import com.wechatjz.api.service.WxApiServicel;
import com.wechatjz.api.service.WxVerificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dome")
public class DomeController {

    @Autowired
    private UserService userService;

    @Autowired
    private WxVerificationService wxVerificationService;

    @Autowired
    private WxApiServicel wxApiServicel;

    @GetMapping("getOpenid")
    public String getOpenid(String code){
        System.out.println(code);
        String res = userService.getOpenid(code).getOpenid();
        System.out.println(res);
        return res;
    }

    @GetMapping("getUser")
    public UserWxVO getUser(String code){
        UserWxVO userWxVO = userService.getUserWx(code);

        return userWxVO;
    }

    @GetMapping("getVerification")
    public String getVerification(@ModelAttribute WxVerificationModel wxVerificationModel){
        String res = wxVerificationService.wxVerification(wxVerificationModel);
        System.out.println(res);

        return res;
    }

    @GetMapping("getJsSign")
    public JsSignVO getJsSign(String url){
        JsSignVO jsSignVO = wxApiServicel.getJsSign(url);

        return jsSignVO;
    }
}
