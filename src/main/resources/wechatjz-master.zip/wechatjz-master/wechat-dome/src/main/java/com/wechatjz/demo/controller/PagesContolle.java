package com.wechatjz.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PagesContolle {
    @RequestMapping("/")
    public String index() {
        return "index";
    }
}
