package com.wechatjz.api.service.impl;

import com.wechatjz.api.model.vo.CodeTokenVO;
import com.wechatjz.api.model.vo.UserWxVO;
import com.wechatjz.api.service.UserService;
import com.wechatjz.api.utils.HttpURLConnectionUtil;
import com.wechatjz.api.utils.JsonUtil;

public class UserServiceImpl extends AbstractService implements UserService {

    @Override
    public CodeTokenVO getOpenid(String code) {
        CodeTokenVO codeTokenVO = codeDeputed(code);
        return codeTokenVO;
    }

    @Override
    public UserWxVO getUserWx(String code) {
        CodeTokenVO codeTokenVO = codeDeputed(code);

        UserWxVO userWxVO = userInfo(codeTokenVO.getOpenid(),codeTokenVO.getAccessToken());
        return userWxVO;
    }

    @Override
    public UserWxVO getUserWx(String openid, String accessToken) {
        UserWxVO userWxVO = userInfo(openid,accessToken);
        return userWxVO;
    }

    /**
     * 通过code换取网页授权access_token及openid
     * @param code
     * @return
     */
    private CodeTokenVO codeDeputed(String code){
        String url = this.url + "/sns/oauth2/access_token";
        String APPID = this.APPID;
        String appsecret = this.appsecret;

        String httpUrl = url + "?appid=" + APPID + "&secret="+ appsecret +"&code="+ code +"&grant_type=authorization_code";
        String jsonStr = HttpURLConnectionUtil.doGet(httpUrl);
        CodeTokenVO codeTokenVO = JsonUtil.getPerson(jsonStr,CodeTokenVO.class);
        return codeTokenVO;
    }

    /**
     * 通过access_token和openid拉取用户信息
     * @param openid
     * @param accessToken
     * @return
     */
    private UserWxVO userInfo(String openid,String accessToken){
        String url = this.url + "/sns/userinfo";

        String httpUrl = url + "?access_token="+ accessToken +"&openid=" + openid + "&lang=zh_CN";
        String jsonStr = HttpURLConnectionUtil.doGet(httpUrl);
//        System.out.println(jsonStr);
        UserWxVO userWxVO = JsonUtil.getPerson(jsonStr,UserWxVO.class);
        return userWxVO;
    }
}
