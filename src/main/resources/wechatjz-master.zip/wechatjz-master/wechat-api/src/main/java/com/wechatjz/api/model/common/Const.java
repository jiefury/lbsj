package com.wechatjz.api.model.common;

public interface Const {

    String URL="wechatjz.url";

    String APPID = "wechatjz.appid";

    String APPSECRET = "wechatjz.appsecret";

    String VTOKEN = "wechatjz.vtoken";
}
