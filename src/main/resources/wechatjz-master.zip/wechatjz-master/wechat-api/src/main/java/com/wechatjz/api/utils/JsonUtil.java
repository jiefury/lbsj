package com.wechatjz.api.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;

public class JsonUtil {
    /**
     * 将Json字符串转换为实例
     * @param jsonstring
     * @param cls
     * @param <T>
     * @return
     */
    public static <T> T getPerson(String jsonstring, Class<T> cls) {
        T t = null;
        try {
            t = JSON.parseObject(jsonstring, cls);
        } catch (Exception e) {
            // TODO: handle exception
        }
        return t;
    }

    /**
     * 将Json转换为指定类型的List
     * @param jsonstring
     * @param cls
     * @param <T>
     * @return
     */
    public static <T> List<T> getPersonList(String jsonstring, Class<T> cls) {
        List<T> list = new ArrayList<>();
        try {
            list = JSON.parseArray(jsonstring, cls);
        } catch (Exception e) {
            // TODO: handle exception
        }
        return list;
    }

    public static <T> Map<String,T> getPersonMap(String jsonstring) {
        Map<String,T> map = new HashMap<>();
        try {
            map = (Map<String, T>) JSON.parseObject(jsonstring);
        } catch (Exception e) {
            // TODO: handle exception
        }
        return map;
    }
}
