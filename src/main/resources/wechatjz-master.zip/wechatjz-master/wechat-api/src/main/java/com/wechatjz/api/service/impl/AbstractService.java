package com.wechatjz.api.service.impl;

import com.wechatjz.api.model.common.Const;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractService {
    protected Logger logger = LoggerFactory.getLogger(getClass());

    protected String url;
    protected String APPID;
    protected String appsecret;

    public void init(final Properties config) {
        String url = config.getProperty(Const.URL);
        String APPID = config.getProperty(Const.APPID);
        String appsecret = config.getProperty(Const.APPSECRET);

        if(null == url || "".equals(url)){
            logger.error(Const.URL+":配置不不能为空");
        }
        if(null == APPID || "".equals(APPID)){
            logger.error(Const.APPID+":配置不不能为空");
        }
        if(null == appsecret || "".equals(appsecret)){
            logger.error(Const.APPSECRET+":配置不不能为空");
        }

        this.url = url;
        this.APPID = APPID;
        this.appsecret = appsecret;
    }
}
