package com.wechatjz.api.service;


import com.wechatjz.api.model.vo.CodeTokenVO;
import com.wechatjz.api.model.vo.UserWxVO;

import java.util.Properties;

public interface UserService {
    void init(final Properties config);

    /**
     * 获取Openid
     * @param code 前端获取的code
     * @return
     */
    CodeTokenVO getOpenid(String code);

    /**
     *
     * @param code 前端获取的code
     * @return
     */
    UserWxVO getUserWx(String code);

    /**
     *
     * @param openid 用户唯一标识
     * @param accessToken 用户调用信息验证的token
     * @return
     */
    UserWxVO getUserWx(String openid,String accessToken);
}
