package com.wechatjz.api.service;

import com.wechatjz.api.model.common.WxVerificationModel;

import java.util.Properties;

public interface WxVerificationService {
    void init(final Properties config);
    String wxVerification(WxVerificationModel wxVerificationModel);
}
