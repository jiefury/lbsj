package com.wechatjz.api.properties;


import org.springframework.boot.context.properties.ConfigurationProperties;

import static com.wechatjz.api.properties.WechatjzProperties.PREFIX;

@ConfigurationProperties(PREFIX)
public class WechatjzProperties {
    public static final String PREFIX = "wechatjz";

    private String url;

    private String APPID;

    private String appsecret;

    private String vToken;

    public String getVToken() {
        return vToken;
    }

    public void setVToken(String vToken) {
        this.vToken = vToken;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAPPID() {
        return APPID;
    }

    public void setAPPID(String APPID) {
        this.APPID = APPID;
    }

    public String getAppsecret() {
        return appsecret;
    }

    public void setAppsecret(String appsecret) {
        this.appsecret = appsecret;
    }

    @Override
    public String toString() {
        return "WechatjzProperties{" +
                "url='" + url + '\'' +
                ", APPID='" + APPID + '\'' +
                ", appsecret='" + appsecret + '\'' +
                '}';
    }
}
