package com.wechatjz.api.service.impl;

import com.wechatjz.api.model.common.Const;
import com.wechatjz.api.model.common.WxVerificationModel;
import com.wechatjz.api.service.WxVerificationService;
import com.wechatjz.api.utils.WxVerificationUtil;

import java.util.Properties;

public class WxVerificationServiceImpl implements WxVerificationService {

    private String Token;

    @Override
    public void init(Properties config) {
        String Token = config.getProperty(Const.VTOKEN);
        this.Token = Token;
    }

    @Override
    public String wxVerification(WxVerificationModel wxVerificationModel) {
        boolean checkSignature = WxVerificationUtil.CheckSignature(wxVerificationModel.getSignature(),wxVerificationModel.getTimestamp(),wxVerificationModel.getNonce(),this.Token);
        if(checkSignature){
            return wxVerificationModel.getEchostr();
        }
        return null;
    }
}
