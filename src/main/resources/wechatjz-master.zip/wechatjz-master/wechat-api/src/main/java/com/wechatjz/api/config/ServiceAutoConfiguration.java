package com.wechatjz.api.config;

import com.wechatjz.api.model.common.Const;
import com.wechatjz.api.service.UserService;
import com.wechatjz.api.service.WxApiServicel;
import com.wechatjz.api.service.WxVerificationService;
import com.wechatjz.api.service.impl.UserServiceImpl;
import com.wechatjz.api.service.impl.WxApiServicelImpl;
import com.wechatjz.api.service.impl.WxVerificationServiceImpl;
import com.wechatjz.api.properties.WechatjzProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

@Configuration
@EnableConfigurationProperties(WechatjzProperties.class)
@ComponentScan("com.wechatjz.api")
public class ServiceAutoConfiguration {

    @Bean(name = "UserService")
//    @ConditionalOnMissingBean
    UserService userService(WechatjzProperties prop){
        UserService userService= new UserServiceImpl();
        Properties config = new Properties();
        config.put(Const.URL,prop.getUrl());
        config.put(Const.APPID,prop.getAPPID());
        config.put(Const.APPSECRET,prop.getAppsecret());
        userService.init(config);
        return userService;
    }

    @Bean(name = "WxVerificationService")
//    @ConditionalOnMissingBean
    WxVerificationService wxVerificationService(WechatjzProperties prop){
        WxVerificationService wxVerificationService = new WxVerificationServiceImpl();
        Properties config = new Properties();
        config.put(Const.VTOKEN,prop.getVToken());
        wxVerificationService.init(config);
        return wxVerificationService;
    }

    @Bean(name = "WxApiServicel")
//    @ConditionalOnMissingBean
    WxApiServicel wxApiServicel(WechatjzProperties prop){
        WxApiServicel wxApiServicel = new WxApiServicelImpl();
        Properties config = new Properties();
        config.put(Const.URL,prop.getUrl());
        config.put(Const.APPID,prop.getAPPID());
        config.put(Const.APPSECRET,prop.getAppsecret());
        wxApiServicel.init(config);
        return wxApiServicel;
    }
}
