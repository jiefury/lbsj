package com.wechatjz.api.service.impl;

import com.wechatjz.api.model.common.AccessTokenModel;
import com.wechatjz.api.model.vo.JsSignVO;
import com.wechatjz.api.service.WxApiServicel;
import com.wechatjz.api.utils.HttpURLConnectionUtil;
import com.wechatjz.api.utils.JsonUtil;
import com.wechatjz.api.utils.WxTokenUtil;
import com.wechatjz.api.utils.WxVerificationUtil;

import java.util.Map;

public class WxApiServicelImpl extends AbstractService implements WxApiServicel {

    @Override
    public JsSignVO getJsSign(String page) {
        AccessTokenModel jsapiTicket = getJsapiTicket();

        JsSignVO jsSignVO = WxVerificationUtil.signatureSha1(jsapiTicket.getTicket(),page);
        String APPID = this.APPID;
        jsSignVO.setAppId(APPID);
        return jsSignVO;
    }

    private AccessTokenModel getAccessToken(){
        String url = this.url + "/cgi-bin/token";
        String APPID = this.APPID;
        String appsecret = this.appsecret;

        AccessTokenModel accessTokenModel = WxTokenUtil.get(APPID + "_token");
        if(null != accessTokenModel){
            return accessTokenModel;
        }

        String httpUrl = url + "?grant_type=client_credential&appid=" + APPID + "&secret=" + appsecret;
        String jsonStr = HttpURLConnectionUtil.doGet(httpUrl);
//        System.out.println(jsonStr);
        accessTokenModel = JsonUtil.getPerson(jsonStr,AccessTokenModel.class);

        WxTokenUtil.set(APPID + "_token",accessTokenModel);
        return accessTokenModel;
    }

    private AccessTokenModel getJsapiTicket (){
        String url = this.url + "/cgi-bin/ticket/getticket";
        String APPID = this.APPID;

        AccessTokenModel jsapiTicket = WxTokenUtil.get(APPID+"_ticket");
        if(null != jsapiTicket){
            return jsapiTicket;
        }

        AccessTokenModel accessTokenModel = getAccessToken();

        String httpUrl = url + "?access_token=" + accessTokenModel.getAccessToken() + "&type=jsapi";
        String jsonStr = HttpURLConnectionUtil.doGet(httpUrl);
//        System.out.println(jsonStr);
        jsapiTicket = JsonUtil.getPerson(jsonStr,AccessTokenModel.class);

        WxTokenUtil.set(APPID+"_ticket",jsapiTicket);
        return jsapiTicket;
    }
}
