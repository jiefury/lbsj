package com.wechatjz.api.service;

import com.wechatjz.api.model.vo.JsSignVO;

import java.util.Properties;

public interface WxApiServicel {
    void init(final Properties config);

    /**
     * 获取jssdk 签名
     * @param page
     * @return
     */
    JsSignVO getJsSign(String page);
}
